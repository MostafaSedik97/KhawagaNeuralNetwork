import matplotlib.pyplot as plt

def Plot(x,y):
  plt.style.use('fivethirtyeight')
  plt.plot(x,y)
  plt.show